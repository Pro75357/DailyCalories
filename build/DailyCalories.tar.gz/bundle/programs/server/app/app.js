var require = meteorInstall({"collections":{"calorieDatabase.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// collections/calorieDatabase.js                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export({
    calorieDatabase: () => calorieDatabase,
    Daily: () => Daily
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
const calorieDatabase = new Mongo.Collection('calorieDatabase');
const Daily = new Mongo.Collection('daily');
Meteor.methods({
    'deleteAll': function () {
        calorieDatabase.remove({});
    }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"upload.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/upload.js                                                                                 //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
let calorieDatabase;
module.watch(require("../collections/calorieDatabase"), {
    calorieDatabase(v) {
        calorieDatabase = v;
    }

}, 0);
Meteor.methods({
    parseUpload(data) {
        check(data, Array);

        for (var x in data) {
            let exists = calorieDatabase.findOne({
                _id: data[x]._id
            });

            if (!exists) {
                if (data[x]._id === "") {// skip the blank file at the end of every papa parsed csv
                } else {
                    calorieDatabase.insert(data[x]);
                }
            } else {
                console.warn('Rejected. This item already exists.');
            }
        }
    }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/main.js                                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {// code to run on server at startup
});
//////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./collections/calorieDatabase.js");
require("./server/upload.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvY2Fsb3JpZURhdGFiYXNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdXBsb2FkLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJjYWxvcmllRGF0YWJhc2UiLCJEYWlseSIsIk1vbmdvIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIkNvbGxlY3Rpb24iLCJNZXRlb3IiLCJtZXRob2RzIiwicmVtb3ZlIiwicGFyc2VVcGxvYWQiLCJkYXRhIiwiY2hlY2siLCJBcnJheSIsIngiLCJleGlzdHMiLCJmaW5kT25lIiwiX2lkIiwiaW5zZXJ0IiwiY29uc29sZSIsIndhcm4iLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MscUJBQWdCLE1BQUlBLGVBQXJCO0FBQXFDQyxXQUFNLE1BQUlBO0FBQS9DLENBQWQ7QUFBcUUsSUFBSUMsS0FBSjtBQUFVSixPQUFPSyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLFVBQU1HLENBQU4sRUFBUTtBQUFDSCxnQkFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUd4RSxNQUFNTCxrQkFBa0IsSUFBSUUsTUFBTUksVUFBVixDQUFxQixpQkFBckIsQ0FBeEI7QUFFQSxNQUFNTCxRQUFRLElBQUlDLE1BQU1JLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUVQQyxPQUFPQyxPQUFQLENBQWU7QUFDWCxpQkFBYSxZQUFVO0FBQ25CUix3QkFBZ0JTLE1BQWhCLENBQXVCLEVBQXZCO0FBQ0g7QUFIVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEEsSUFBSVQsZUFBSjtBQUFvQkYsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLGdDQUFSLENBQWIsRUFBdUQ7QUFBQ0osb0JBQWdCSyxDQUFoQixFQUFrQjtBQUFDTCwwQkFBZ0JLLENBQWhCO0FBQWtCOztBQUF0QyxDQUF2RCxFQUErRixDQUEvRjtBQUVwQkUsT0FBT0MsT0FBUCxDQUFlO0FBQ1hFLGdCQUFZQyxJQUFaLEVBQWtCO0FBQ2RDLGNBQU9ELElBQVAsRUFBYUUsS0FBYjs7QUFFQSxhQUFNLElBQUlDLENBQVYsSUFBZUgsSUFBZixFQUFxQjtBQUNiLGdCQUFJSSxTQUFTZixnQkFBZ0JnQixPQUFoQixDQUF5QjtBQUFFQyxxQkFBS04sS0FBS0csQ0FBTCxFQUFRRztBQUFmLGFBQXpCLENBQWI7O0FBRUosZ0JBQUssQ0FBQ0YsTUFBTixFQUFlO0FBQ1gsb0JBQUlKLEtBQUtHLENBQUwsRUFBUUcsR0FBUixLQUFnQixFQUFwQixFQUF1QixDQUNuQjtBQUNILGlCQUZELE1BRU87QUFDSGpCLG9DQUFnQmtCLE1BQWhCLENBQXVCUCxLQUFLRyxDQUFMLENBQXZCO0FBQ0g7QUFDSixhQU5ELE1BTU87QUFDSEssd0JBQVFDLElBQVIsQ0FBYyxxQ0FBZDtBQUNIO0FBQ0o7QUFDSjs7QUFqQlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ0ZBLElBQUliLE1BQUo7QUFBV1QsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRyxTQUFPRixDQUFQLEVBQVM7QUFBQ0UsYUFBT0YsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUVYRSxPQUFPYyxPQUFQLENBQWUsTUFBTSxDQUNuQjtBQUNELENBRkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcblxyXG4vL0NyZWF0ZSB0aGUgZGF0YWJhc2VcclxuZXhwb3J0IGNvbnN0IGNhbG9yaWVEYXRhYmFzZSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjYWxvcmllRGF0YWJhc2UnKVxyXG5cclxuZXhwb3J0IGNvbnN0IERhaWx5ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2RhaWx5JylcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdkZWxldGVBbGwnOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIGNhbG9yaWVEYXRhYmFzZS5yZW1vdmUoe30pXHJcbiAgICB9XHJcbn0pIiwiaW1wb3J0IHsgY2Fsb3JpZURhdGFiYXNlIH0gZnJvbSBcIi4uL2NvbGxlY3Rpb25zL2NhbG9yaWVEYXRhYmFzZVwiO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgcGFyc2VVcGxvYWQoZGF0YSkge1xyXG4gICAgICAgIGNoZWNrKCBkYXRhLCBBcnJheSApO1xyXG5cclxuICAgICAgICBmb3IgKCB2YXIgeCBpbiBkYXRhKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgZXhpc3RzID0gY2Fsb3JpZURhdGFiYXNlLmZpbmRPbmUoIHsgX2lkOiBkYXRhW3hdLl9pZCB9ICk7XHJcblxyXG4gICAgICAgICAgICBpZiAoICFleGlzdHMgKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZGF0YVt4XS5faWQgPT09IFwiXCIpe1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHNraXAgdGhlIGJsYW5rIGZpbGUgYXQgdGhlIGVuZCBvZiBldmVyeSBwYXBhIHBhcnNlZCBjc3ZcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2Fsb3JpZURhdGFiYXNlLmluc2VydChkYXRhW3hdKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybiggJ1JlamVjdGVkLiBUaGlzIGl0ZW0gYWxyZWFkeSBleGlzdHMuJyApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxyXG59KTtcclxuXHJcbiJdfQ==
