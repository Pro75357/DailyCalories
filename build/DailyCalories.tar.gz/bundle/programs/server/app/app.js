var require = meteorInstall({"collections":{"calorieDatabase.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// collections/calorieDatabase.js                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export({
    calorieDatabase: () => calorieDatabase,
    Daily: () => Daily
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
const calorieDatabase = new Mongo.Collection('calorieDatabase');
const Daily = new Mongo.Collection('daily');
Meteor.methods({
    'deleteAll': function () {
        calorieDatabase.remove({});
    }
});

if (Meteor.isServer) {
    Meteor.publish('calorieDatabase', function () {
        return calorieDatabase.find({
            userId: Meteor.userId()
        });
    });
    Meteor.publish('daily', function () {
        return Daily.find({
            userId: Meteor.userId()
        });
    });
}

if (Meteor.isClient) {
    Meteor.subscribe('calorieDatabase');
    Meteor.subscribe('daily');
}
//////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"upload.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/upload.js                                                                                 //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
let calorieDatabase;
module.watch(require("../collections/calorieDatabase"), {
    calorieDatabase(v) {
        calorieDatabase = v;
    }

}, 0);
Meteor.methods({
    parseUpload(data) {
        check(data, Array);

        for (var x in data) {
            let exists = calorieDatabase.findOne({
                _id: data[x]._id
            });

            if (!exists) {
                if (data[x]._id === "") {// skip the blank file at the end of every papa parsed csv
                } else {
                    data[x].userId = Meteor.userId();
                    calorieDatabase.insert(data[x]);
                }
            } else {
                console.warn('Rejected. This item already exists.');
            }
        }
    }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/main.js                                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {// code to run on server at startup
});
//////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./collections/calorieDatabase.js");
require("./server/upload.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvY2Fsb3JpZURhdGFiYXNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdXBsb2FkLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJjYWxvcmllRGF0YWJhc2UiLCJEYWlseSIsIk1vbmdvIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIkNvbGxlY3Rpb24iLCJNZXRlb3IiLCJtZXRob2RzIiwicmVtb3ZlIiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwiZmluZCIsInVzZXJJZCIsImlzQ2xpZW50Iiwic3Vic2NyaWJlIiwicGFyc2VVcGxvYWQiLCJkYXRhIiwiY2hlY2siLCJBcnJheSIsIngiLCJleGlzdHMiLCJmaW5kT25lIiwiX2lkIiwiaW5zZXJ0IiwiY29uc29sZSIsIndhcm4iLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MscUJBQWdCLE1BQUlBLGVBQXJCO0FBQXFDQyxXQUFNLE1BQUlBO0FBQS9DLENBQWQ7QUFBcUUsSUFBSUMsS0FBSjtBQUFVSixPQUFPSyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNGLFVBQU1HLENBQU4sRUFBUTtBQUFDSCxnQkFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUd4RSxNQUFNTCxrQkFBa0IsSUFBSUUsTUFBTUksVUFBVixDQUFxQixpQkFBckIsQ0FBeEI7QUFFQSxNQUFNTCxRQUFRLElBQUlDLE1BQU1JLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUVQQyxPQUFPQyxPQUFQLENBQWU7QUFDWCxpQkFBYSxZQUFVO0FBQ25CUix3QkFBZ0JTLE1BQWhCLENBQXVCLEVBQXZCO0FBQ0g7QUFIVSxDQUFmOztBQU1BLElBQUdGLE9BQU9HLFFBQVYsRUFBbUI7QUFDZkgsV0FBT0ksT0FBUCxDQUFlLGlCQUFmLEVBQWtDLFlBQVU7QUFDeEMsZUFBT1gsZ0JBQWdCWSxJQUFoQixDQUFxQjtBQUN4QkMsb0JBQVFOLE9BQU9NLE1BQVA7QUFEZ0IsU0FBckIsQ0FBUDtBQUdILEtBSkQ7QUFLQU4sV0FBT0ksT0FBUCxDQUFlLE9BQWYsRUFBd0IsWUFBVTtBQUM5QixlQUFPVixNQUFNVyxJQUFOLENBQVc7QUFDZEMsb0JBQVFOLE9BQU9NLE1BQVA7QUFETSxTQUFYLENBQVA7QUFHSCxLQUpEO0FBS0g7O0FBRUQsSUFBSU4sT0FBT08sUUFBWCxFQUFvQjtBQUNoQlAsV0FBT1EsU0FBUCxDQUFpQixpQkFBakI7QUFDQVIsV0FBT1EsU0FBUCxDQUFpQixPQUFqQjtBQUNILEM7Ozs7Ozs7Ozs7O0FDN0JELElBQUlmLGVBQUo7QUFBb0JGLE9BQU9LLEtBQVAsQ0FBYUMsUUFBUSxnQ0FBUixDQUFiLEVBQXVEO0FBQUNKLG9CQUFnQkssQ0FBaEIsRUFBa0I7QUFBQ0wsMEJBQWdCSyxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBdkQsRUFBK0YsQ0FBL0Y7QUFFcEJFLE9BQU9DLE9BQVAsQ0FBZTtBQUNYUSxnQkFBWUMsSUFBWixFQUFrQjtBQUNkQyxjQUFPRCxJQUFQLEVBQWFFLEtBQWI7O0FBRUEsYUFBTSxJQUFJQyxDQUFWLElBQWVILElBQWYsRUFBcUI7QUFDYixnQkFBSUksU0FBU3JCLGdCQUFnQnNCLE9BQWhCLENBQXlCO0FBQUVDLHFCQUFLTixLQUFLRyxDQUFMLEVBQVFHO0FBQWYsYUFBekIsQ0FBYjs7QUFFSixnQkFBSyxDQUFDRixNQUFOLEVBQWU7QUFDWCxvQkFBSUosS0FBS0csQ0FBTCxFQUFRRyxHQUFSLEtBQWdCLEVBQXBCLEVBQXVCLENBQ25CO0FBQ0gsaUJBRkQsTUFFTztBQUNITix5QkFBS0csQ0FBTCxFQUFRUCxNQUFSLEdBQWlCTixPQUFPTSxNQUFQLEVBQWpCO0FBQ0FiLG9DQUFnQndCLE1BQWhCLENBQXVCUCxLQUFLRyxDQUFMLENBQXZCO0FBQ0g7QUFDSixhQVBELE1BT087QUFDSEssd0JBQVFDLElBQVIsQ0FBYyxxQ0FBZDtBQUNIO0FBQ0o7QUFDSjs7QUFsQlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ0ZBLElBQUluQixNQUFKO0FBQVdULE9BQU9LLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0csU0FBT0YsQ0FBUCxFQUFTO0FBQUNFLGFBQU9GLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFFWEUsT0FBT29CLE9BQVAsQ0FBZSxNQUFNLENBQ25CO0FBQ0QsQ0FGRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcclxuXHJcbi8vQ3JlYXRlIHRoZSBkYXRhYmFzZVxyXG5leHBvcnQgY29uc3QgY2Fsb3JpZURhdGFiYXNlID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NhbG9yaWVEYXRhYmFzZScpXHJcblxyXG5leHBvcnQgY29uc3QgRGFpbHkgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZGFpbHknKVxyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgJ2RlbGV0ZUFsbCc6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2Fsb3JpZURhdGFiYXNlLnJlbW92ZSh7fSlcclxuICAgIH1cclxufSk7XHJcblxyXG5pZihNZXRlb3IuaXNTZXJ2ZXIpe1xyXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ2NhbG9yaWVEYXRhYmFzZScsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgcmV0dXJuIGNhbG9yaWVEYXRhYmFzZS5maW5kKHtcclxuICAgICAgICAgICAgdXNlcklkOiBNZXRlb3IudXNlcklkKClcclxuICAgICAgICB9KVxyXG4gICAgfSk7XHJcbiAgICBNZXRlb3IucHVibGlzaCgnZGFpbHknLCBmdW5jdGlvbigpe1xyXG4gICAgICAgIHJldHVybiBEYWlseS5maW5kKHtcclxuICAgICAgICAgICAgdXNlcklkOiBNZXRlb3IudXNlcklkKClcclxuICAgICAgICB9KVxyXG4gICAgfSk7XHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpe1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnY2Fsb3JpZURhdGFiYXNlJyk7XHJcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdkYWlseScpO1xyXG59IiwiaW1wb3J0IHsgY2Fsb3JpZURhdGFiYXNlIH0gZnJvbSBcIi4uL2NvbGxlY3Rpb25zL2NhbG9yaWVEYXRhYmFzZVwiO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgcGFyc2VVcGxvYWQoZGF0YSkge1xyXG4gICAgICAgIGNoZWNrKCBkYXRhLCBBcnJheSApO1xyXG5cclxuICAgICAgICBmb3IgKCB2YXIgeCBpbiBkYXRhKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgZXhpc3RzID0gY2Fsb3JpZURhdGFiYXNlLmZpbmRPbmUoIHsgX2lkOiBkYXRhW3hdLl9pZCB9ICk7XHJcblxyXG4gICAgICAgICAgICBpZiAoICFleGlzdHMgKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZGF0YVt4XS5faWQgPT09IFwiXCIpe1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHNraXAgdGhlIGJsYW5rIGZpbGUgYXQgdGhlIGVuZCBvZiBldmVyeSBwYXBhIHBhcnNlZCBjc3ZcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YVt4XS51c2VySWQgPSBNZXRlb3IudXNlcklkKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2Fsb3JpZURhdGFiYXNlLmluc2VydChkYXRhW3hdKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybiggJ1JlamVjdGVkLiBUaGlzIGl0ZW0gYWxyZWFkeSBleGlzdHMuJyApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxyXG59KTtcclxuIl19
